package com.example.usuario.proyectoorma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.usuario.proyectoorma.modelo.Pedido;

public class ActiveAndroid extends AppCompatActivity implements View.OnClickListener {
    EditText hamburguesa, cerveza, ensalada, salchipapa;
    TextView pedido;
    Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_android);

        hamburguesa = (EditText) findViewById(R.id.txtHamburguesa);
        cerveza = (EditText) findViewById(R.id.txtCerveza);
        ensalada = (EditText) findViewById(R.id.txtEnsalada);
        salchipapa = (EditText) findViewById(R.id.txtSalchipapa);

        calcular = (Button) findViewById(R.id.btnCalcularpedido);
        pedido = (TextView) findViewById(R.id.lblTotalPedido);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.btnCalcularpedido:
                Pedido pedido = new Pedido();


                pedido.setHamburguesa(hamburguesa.getText().toString());
                pedido.setCerveza(cerveza.getText().toString());
                pedido.setEnsalada(ensalada.getText().toString());
                pedido.setSalchipapa(salchipapa.getText().toString());
                pedido.save();
                break;



        }
    }
}
