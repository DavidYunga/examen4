package com.example.usuario.proyectoorma.modelo;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;
import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;

import java.util.List;

@Table(name = "pedido")
public class Pedido extends Model {
    @Column(name="hamburguesa", notNull = true)
    private String hamburguesa;
    @Column(name ="cerveza", unique = true)
    private String cerveza;
    @Column(name ="ensalada", notNull = true)
    private String ensalada;
    @Column(name ="salchipapa", notNull = true)
    private String salchipapa;



    public Pedido(){
        super();
    }

    public Pedido(String hamburguesa, String cerveza, String ensalada, String salchipapa) {
        super();
        this.hamburguesa = hamburguesa;
        this.cerveza = cerveza;
        this.ensalada = ensalada;
        this.salchipapa= salchipapa;
    }

    public List<Pedido> obtenerTodosProducto(){
        return new Select().from(Pedido.class).execute();
   }

    public void eliminarTodo(){

        new Delete().from(Pedido.class).execute();
    }

    public Pedido eliminarProdustos(String codigo){
        return  new Select().from(Pedido.class).where("codigo ='"+codigo+"'").executeSingle();
    }

    public Pedido buscarPorCod(String codigo){
        return new Select().from(Pedido.class).where("codigo ='"+codigo+"'").executeSingle();

    }

    public String getHamburguesa() {
        return hamburguesa;
    }

    public void setHamburguesa(String hamburguesa) {
        this.hamburguesa = hamburguesa;
    }

    public String getCerveza() {
        return cerveza;
    }

    public void setCerveza(String cerveza) {
        this.cerveza = cerveza;
    }

    public String getEnsalada() {
        return ensalada;
    }

    public void setEnsalada(String ensalada) {
        this.ensalada = ensalada;
    }

    public String getSalchipapa() {
        return salchipapa;
    }

    public void setSalchipapa(String salchipapa) {
        this.salchipapa = salchipapa;
    }
}
